﻿using System.Web.UI;

namespace DevesTestWebAPI.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}