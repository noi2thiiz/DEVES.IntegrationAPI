﻿namespace DEVES.IntegrationAPI.WebApi.Logic
{
    internal class TransformCLSCreatePersonalClientInputModel
    {
    }
}