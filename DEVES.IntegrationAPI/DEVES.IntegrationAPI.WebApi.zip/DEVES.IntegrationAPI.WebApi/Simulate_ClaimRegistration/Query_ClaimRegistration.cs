﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DEVES.IntegrationAPI.WebApi.Simulate_ClaimRegistration
{
    public class Query_ClaimRegistration
    {

    }
}