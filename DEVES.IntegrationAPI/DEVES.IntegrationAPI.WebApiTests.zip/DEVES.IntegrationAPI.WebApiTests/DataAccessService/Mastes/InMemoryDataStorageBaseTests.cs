﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using DEVES.IntegrationAPI.WebApi.DataAccessService.MasterData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEVES.IntegrationAPI.WebApi.DataAccessService.MasterData.Tests
{
    [TestClass()]
    public class InMemoryDataStorageBaseTests
    {
        [TestMethod()]
        public void InitTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void TranformTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void FindTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void FindByCodeTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void LoadMockDataTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void InitAllTest()
        {
            Assert.Fail();
        }
    }
}